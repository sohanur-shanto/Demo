from django.shortcuts import render


def show(request):
    showvalue = request.POST.get('text','default')
	print(showvalue)
	return render(request,'home.html')